c_air = 343 #m/s
class Water:
	def __init__(self):
		self.name = 'water'
		self.c = 4.3*c_air
		